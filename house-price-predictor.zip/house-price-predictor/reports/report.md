# House Price Predictor — Detailed Report

## 1. Problem Statement

Predict the sale price of a residential home in Ames, Iowa using its physical and quality characteristics. This is a regression task: the target (`SalePrice`) is continuous, ranging from $34,900 to $755,000 in the dataset.

**Goal:** minimize prediction error (RMSE/MAE) while keeping the model interpretable — coefficients should make intuitive sense (e.g. more square footage → higher price).

## 2. Dataset

- **Source:** Ames Housing dataset (Dean De Cock), distributed as the training set for Kaggle's "House Prices: Advanced Regression Techniques" competition — the modern, better-documented successor to the deprecated Boston Housing dataset.
- **Raw size:** 1,460 houses × 81 columns (79 explanatory features + Id + SalePrice)
- **This project's feature subset:** 11 numeric + 1 categorical (`Neighborhood`, one-hot encoded), selected by correlation strength with `SalePrice` (see table below) rather than naively using all 79 raw columns
- **Missing values:** zero in the selected feature subset (verified in `src/preprocessing.py`)
- Full column definitions: [`data/DATA_DICTIONARY.md`](../data/DATA_DICTIONARY.md)

### 2.1 Target Distribution & Why We Log-Transform It

![SalePrice Distribution](figures/01_saleprice_distribution.png)

Raw `SalePrice` has a skew of **1.88** — strongly right-skewed (a few very expensive houses pull the tail out). Applying `log(1+price)` reduces skew to near-zero, which both (a) makes the linear relationship between features and price more linear, and (b) stabilizes the variance of residuals — both are assumptions linear regression relies on. All models in this project are trained on `log(1+SalePrice)` and metrics are reported in both log-scale and back-transformed dollars for interpretability.

### 2.2 Feature Correlations with Price

![Correlation Heatmap](figures/02_correlation_heatmap.png)

| Feature | Correlation with SalePrice |
|---|---|
| `OverallQual` | +0.791 |
| `GrLivArea` | +0.709 |
| `GarageCars` | +0.640 |
| `GarageArea` | +0.623 |
| `TotalBsmtSF` | +0.614 |
| `1stFlrSF` | +0.606 |
| `FullBath` | +0.561 |
| `TotRmsAbvGrd` | +0.534 |
| `YearBuilt` | +0.523 |
| `YearRemodAdd` | +0.507 |
| `Fireplaces` | +0.467 |

Overall quality and living area are by far the two strongest single predictors — consistent with every published analysis of this dataset.

### 2.3 Top Feature Relationships

![Scatterplots](figures/03_top_feature_scatterplots.png)

### 2.4 Price by Neighborhood

![Neighborhood Boxplot](figures/04_saleprice_by_neighborhood.png)

Location matters enormously: median prices vary by more than 3x between the cheapest and most expensive neighborhoods in the dataset, which is why `Neighborhood` is included as a categorical feature (one-hot encoded, with neighborhoods having fewer than 20 houses grouped into "Other" to avoid sparse, unstable columns).

## 3. Methodology

### 3.1 Preprocessing
- Rare neighborhoods (<20 houses) grouped into `"Other"` for encoding stability
- `Neighborhood` one-hot encoded (`drop_first=True` to avoid multicollinearity)
- `SalePrice` log-transformed (`log1p`)
- 80/20 train/test split, `random_state=42`
- Numeric features standardized using a **from-scratch StandardScaler**, fit only on the training set

### 3.2 Models Implemented

**A. From-scratch Linear Regression** (`src/linear_regression_scratch.py`):

```
y_hat = w·x + b
J(w,b) = (1/2m) * Σ(y_hat - y)²
dJ/dw = (1/m) * Xᵗ(y_hat - y)
dJ/db = (1/m) * Σ(y_hat - y)
```

implemented in **four variants**:
1. **Normal Equation** (closed-form): `w = (XᵗX)⁻¹Xᵗy`, solved via `np.linalg.lstsq` for numerical stability — exact solution, no iteration
2. **Batch Gradient Descent (GD)**
3. **Stochastic Gradient Descent (SGD)**
4. **Mini-batch Gradient Descent**

**B. sklearn LinearRegression** — benchmark baseline.

All metrics (RMSE, MAE, R²) implemented from scratch in `src/evaluate.py` and validated against `sklearn.metrics` on synthetic data to machine precision before being trusted for this report.

### 3.3 A Real Tuning Story: Why SGD Needed Different Hyperparameters

Initial SGD runs with the same learning rate used for the heart-disease project's logistic regression (`lr=0.05`, 5000 iterations) produced a poor result: **R² = 0.41**. Diagnosing this (rather than reporting it as "SGD is just worse") revealed it was a hyperparameter problem, not a bug: with 30 features (vs 13 in the logistic regression project), SGD's single-sample gradient estimate is noisier in higher dimensions and needs a smaller learning rate plus more iterations to average out that noise. A small grid search found `lr=0.01, n_iters=20000` recovers **R² = 0.843** — much more consistent with GD and sklearn. This is documented here deliberately: a from-scratch implementation being "correct" doesn't mean it's hyperparameter-free, and tuning is part of the real work.

### 3.4 Training Loss Curves

![Loss Curves](figures/05_loss_curves_gd_sgd_minibatch.png)

GD (blue) converges smoothly and reaches the lowest final loss. Mini-batch (green) is close behind. SGD (red) is visibly noisier throughout — its single-sample updates produce periodic spikes — and settles at a slightly higher loss plateau, consistent with its lower R² score.

## 4. Results

| Model | R² | RMSE (log) | MAE (log) | RMSE ($) | MAE ($) | Train Time |
|---|---|---|---|---|---|---|
| Linear Regression (Normal Equation, scratch) | 0.8703 | 0.1556 | 0.1096 | $29,528 | $19,034 | 0.001s |
| Linear Regression (GD, scratch) | **0.8710** | 0.1551 | 0.1094 | $29,513 | $19,019 | 0.31s |
| Linear Regression (SGD, scratch) | 0.8432 | 0.1711 | 0.1265 | $31,630 | $22,010 | 1.01s |
| Linear Regression (Mini-batch, scratch) | 0.8657 | 0.1583 | 0.1092 | $29,128 | $18,996 | 0.79s |
| **Linear Regression (sklearn)** | 0.8703 | 0.1556 | 0.1096 | $29,528 | $19,034 | **0.002s** |

### 4.1 Actual vs Predicted

![Actual vs Predicted](figures/06_actual_vs_predicted.png)

The from-scratch GD model (left) and sklearn (right) are visually indistinguishable — both track the diagonal "perfect prediction" line closely, with the expected wider spread at high prices where training data is sparser.

### 4.2 Residual Analysis

![Residuals](figures/07_residual_analysis.png)

Residuals are roughly centered at zero and approximately normally distributed, with a mild right tail (a handful of luxury homes are harder to predict precisely) — a healthy diagnostic pattern for a linear model.

### 4.3 3D Regression Surface

Using the two strongest continuous predictors (Overall Quality, Living Area), refit as a standalone 2-feature model purely for visualization:

![3D Surface](figures/08_3d_regression_surface.png)

## 5. Discussion

- **The Normal Equation and sklearn produce identical results** (R²=0.8703 for both) — expected, since both solve the same linear least-squares system exactly, just via different numerical routes.
- **GD essentially matches the closed-form solution** (R²=0.8710 vs 0.8703) once given enough iterations (5000) and an appropriately large learning rate (0.3) for this standardized feature space.
- **The Normal Equation is dramatically faster** (0.001s vs 0.31s for GD) because it requires no iteration — for a dataset this size (1168 training rows × 30 features), solving the linear system directly is cheap. This is the practical lesson: closed-form solutions win when the feature count is low enough that the underlying matrix operations stay cheap; iterative methods become necessary at much larger scale (millions of features, or models like logistic regression with no closed form at all).
- **SGD needed separate hyperparameter tuning** to perform competitively (see §3.3) — a useful, honest finding about how optimizer noise scales with dimensionality.

## 6. Limitations & Honest Caveats

- **Feature subset, not the full 79 columns** — this project intentionally used the 11 strongest numeric predictors + neighborhood for interpretability and to keep the from-scratch implementation's feature space manageable. A production model competing on Kaggle would likely use many more engineered features and could reach R² > 0.90.
- **Data is from 2006–2010** (Ames, Iowa) — includes the 2008 financial crisis period, which may affect price patterns; not necessarily generalizable to other markets or time periods.
- **Linear regression assumes linear relationships** — quality scores and the log-price transform help, but some true relationships (e.g. diminishing returns on extra bathrooms) may be better captured by non-linear models.

## 7. How to Reproduce

```bash
pip install -r requirements.txt
python data/download_data.py
python src/train_and_compare.py      # prints metrics, saves comparison CSV
python src/generate_visuals.py       # regenerates all figures in reports/figures/
```
