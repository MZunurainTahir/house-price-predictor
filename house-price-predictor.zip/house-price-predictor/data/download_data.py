"""
download_data.py
-----------------
Downloads the Ames Housing dataset (Kaggle's "House Prices: Advanced
Regression Techniques" training set), compiled by Dean De Cock as a
modern, richer alternative to the deprecated Boston Housing dataset.

Source mirror: a long-standing, widely-cited GitHub mirror of the
official Kaggle train.csv (1460 houses, 81 columns incl. SalePrice).
Original competition: https://www.kaggle.com/c/house-prices-advanced-regression-techniques

Usage:
    python download_data.py
"""

import os
import urllib.request

DATA_URL = "https://raw.githubusercontent.com/hjhuney/Data/master/AmesHousing/train.csv"
OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "ames_housing.csv")


def download():
    if os.path.exists(OUTPUT_PATH):
        print(f"Dataset already exists at {OUTPUT_PATH}. Skipping download.")
        return

    print(f"Downloading dataset from {DATA_URL} ...")
    urllib.request.urlretrieve(DATA_URL, OUTPUT_PATH)
    print(f"Saved to {OUTPUT_PATH}")


if __name__ == "__main__":
    download()
