# Data Dictionary — Ames Housing Dataset (Selected Features)

The raw dataset has **1460 houses × 81 columns**. This project uses a focused subset of
the strongest, most interpretable predictors of `SalePrice` (rather than naively
one-hot-encoding all 79 raw features), selected by correlation analysis (see `reports/report.md`).

| Column | Type | Description |
|---|---|---|
| `OverallQual` | ordinal (1–10) | Overall material and finish quality |
| `GrLivArea` | numeric | Above-grade (ground) living area, square feet |
| `GarageCars` | numeric | Size of garage in car capacity |
| `GarageArea` | numeric | Size of garage, square feet |
| `TotalBsmtSF` | numeric | Total basement area, square feet |
| `1stFlrSF` | numeric | First floor square feet |
| `FullBath` | numeric | Full bathrooms above grade |
| `TotRmsAbvGrd` | numeric | Total rooms above grade (excludes bathrooms) |
| `YearBuilt` | numeric | Original construction year |
| `YearRemodAdd` | numeric | Remodel year (same as YearBuilt if no remodel) |
| `Fireplaces` | numeric | Number of fireplaces |
| `Neighborhood` | categorical | Physical location within Ames city limits (one-hot encoded) |
| `SalePrice` | **target** | Sale price in USD |

Full 81-column documentation is part of the original Kaggle competition data description (`data_description.txt` on Kaggle); this project documents only the columns actually used.

**Missing values in this subset:** none of the selected numeric columns have missing values in the raw data (verified in `src/preprocessing.py`'s data quality check). `Neighborhood` has no missing values either.
