"""
generate_visuals.py
--------------------
Generates all charts for the report: EDA plots, correlation heatmap,
loss/convergence curves, actual-vs-predicted plots, residual plots,
and a 3D surface visualization of price vs two key features.

All figures are saved to reports/figures/.
"""

import sys
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

sys.path.append(os.path.dirname(__file__))

from preprocessing import load_data, get_train_test_split
from train_and_compare import run

FIG_DIR = os.path.join(os.path.dirname(__file__), "..", "reports", "figures")
os.makedirs(FIG_DIR, exist_ok=True)

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 120


def save(fig, name):
    path = os.path.join(FIG_DIR, name)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved {path}")


def plot_saleprice_distribution(df):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    sns.histplot(df["SalePrice"], kde=True, ax=axes[0], color="#4C72B0")
    axes[0].set_title(f"SalePrice Distribution (skew={df['SalePrice'].skew():.2f})")
    sns.histplot(np.log1p(df["SalePrice"]), kde=True, ax=axes[1], color="#55A868")
    axes[1].set_title(f"log(1+SalePrice) Distribution (skew={np.log1p(df['SalePrice']).skew():.2f})")
    fig.tight_layout()
    save(fig, "01_saleprice_distribution.png")


def plot_correlation_heatmap(df):
    numeric_df = df.select_dtypes(include=["int64", "float64"])
    fig, ax = plt.subplots(figsize=(9, 7))
    sns.heatmap(numeric_df.corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax, square=True)
    ax.set_title("Numeric Feature Correlation Heatmap")
    save(fig, "02_correlation_heatmap.png")


def plot_top_feature_scatter(df):
    fig, axes = plt.subplots(2, 2, figsize=(11, 9))
    pairs = [
        ("OverallQual", "Overall Quality (1-10)"),
        ("GrLivArea", "Above-Grade Living Area (sqft)"),
        ("TotalBsmtSF", "Total Basement Area (sqft)"),
        ("GarageCars", "Garage Capacity (cars)"),
    ]
    for ax, (col, title) in zip(axes.flatten(), pairs):
        ax.scatter(df[col], df["SalePrice"], alpha=0.35, s=15, color="#4C72B0")
        ax.set_xlabel(title)
        ax.set_ylabel("SalePrice ($)")
        ax.set_title(f"SalePrice vs {title}")
    fig.tight_layout()
    save(fig, "03_top_feature_scatterplots.png")


def plot_neighborhood_boxplot(df):
    fig, ax = plt.subplots(figsize=(13, 5))
    order = df.groupby("Neighborhood")["SalePrice"].median().sort_values(ascending=False).index
    sns.boxplot(data=df, x="Neighborhood", y="SalePrice", order=order, ax=ax, color="#4C72B0")
    ax.set_title("SalePrice by Neighborhood (sorted by median price)")
    ax.tick_params(axis="x", rotation=75)
    fig.tight_layout()
    save(fig, "04_saleprice_by_neighborhood.png")


def plot_loss_curves(histories):
    fig, ax = plt.subplots(figsize=(7, 5))
    colors = {"GD": "#4C72B0", "SGD": "#C44E52", "Mini-batch": "#55A868"}
    for label, history in histories.items():
        if "Normal Equation" in label:
            continue  # not iterative, nothing to plot
        if "SGD" in label:
            short = "SGD"
        elif "Mini-batch" in label:
            short = "Mini-batch"
        elif "GD" in label:
            short = "GD"
        else:
            short = label
        ax.plot(history, label=short, color=colors.get(short), linewidth=1.3)
    ax.set_xlabel("Iteration / Epoch")
    ax.set_ylabel("MSE Loss (log-price scale)")
    ax.set_title("Training Loss Curves: GD vs SGD vs Mini-batch")
    ax.set_yscale("log")
    ax.legend()
    save(fig, "05_loss_curves_gd_sgd_minibatch.png")


def plot_actual_vs_predicted(y_test, predictions_dict):
    fig, axes = plt.subplots(1, len(predictions_dict), figsize=(5 * len(predictions_dict), 5))
    y_test_dollars = np.expm1(y_test)
    for ax, (label, y_pred) in zip(axes, predictions_dict.items()):
        y_pred_dollars = np.expm1(y_pred)
        ax.scatter(y_test_dollars, y_pred_dollars, alpha=0.4, s=15, color="#4C72B0")
        lims = [min(y_test_dollars.min(), y_pred_dollars.min()), max(y_test_dollars.max(), y_pred_dollars.max())]
        ax.plot(lims, lims, "r--", linewidth=1.5, label="Perfect prediction")
        ax.set_xlabel("Actual Sale Price ($)")
        ax.set_ylabel("Predicted Sale Price ($)")
        ax.set_title(label, fontsize=10)
        ax.legend(fontsize=8)
    fig.tight_layout()
    save(fig, "06_actual_vs_predicted.png")


def plot_residuals(y_test, y_pred, label="GD (from scratch)"):
    residuals = np.expm1(y_test) - np.expm1(y_pred)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    axes[0].scatter(np.expm1(y_pred), residuals, alpha=0.4, s=15, color="#4C72B0")
    axes[0].axhline(0, color="red", linestyle="--", linewidth=1.5)
    axes[0].set_xlabel("Predicted Sale Price ($)")
    axes[0].set_ylabel("Residual ($)")
    axes[0].set_title(f"Residuals vs Predicted — {label}")

    sns.histplot(residuals, kde=True, ax=axes[1], color="#55A868")
    axes[1].set_title("Residual Distribution")
    axes[1].set_xlabel("Residual ($)")
    fig.tight_layout()
    save(fig, "07_residual_analysis.png")


def plot_3d_price_surface(X_train, y_train, feature_names):
    """
    3D visualization: SalePrice (log) as a function of the two strongest
    continuous predictors - OverallQual and GrLivArea - with the fitted
    regression plane. Refit a 2-feature-only model purely for visualization
    (the real model uses all 30 features).
    """
    from linear_regression_scratch import LinearRegressionScratch

    idx_qual = feature_names.index("OverallQual")
    idx_area = feature_names.index("GrLivArea")

    X_vis = X_train[:, [idx_qual, idx_area]]
    model_vis = LinearRegressionScratch(learning_rate=0.1, n_iters=2000, method="gd")
    model_vis.fit(X_vis, y_train)

    fig = plt.figure(figsize=(9, 7))
    ax = fig.add_subplot(111, projection="3d")

    ax.scatter(
        X_vis[:, 0], X_vis[:, 1], y_train,
        c=y_train, cmap="viridis", s=20, alpha=0.7, edgecolor="k", linewidth=0.2
    )

    xx, yy = np.meshgrid(
        np.linspace(X_vis[:, 0].min(), X_vis[:, 0].max(), 15),
        np.linspace(X_vis[:, 1].min(), X_vis[:, 1].max(), 15),
    )
    zz = model_vis.weights[0] * xx + model_vis.weights[1] * yy + model_vis.bias
    ax.plot_surface(xx, yy, zz, alpha=0.4, color="orange")

    ax.set_xlabel("Overall Quality (standardized)")
    ax.set_ylabel("Living Area (standardized)")
    ax.set_zlabel("log(1+SalePrice)")
    ax.set_title("3D Regression Surface: Quality & Living Area vs log(Price)")
    save(fig, "08_3d_regression_surface.png")


if __name__ == "__main__":
    df = load_data()

    print("Generating EDA plots...")
    plot_saleprice_distribution(df)
    plot_correlation_heatmap(df)
    plot_top_feature_scatter(df)
    plot_neighborhood_boxplot(df)

    print("\nRunning models for result-based plots...")
    results_df, histories, X_train, X_test, y_train, y_test, feature_names, df2 = run()

    plot_loss_curves(histories)

    from linear_regression_scratch import LinearRegressionScratch
    from sklearn.linear_model import LinearRegression as SklearnLinReg

    gd_model = LinearRegressionScratch(learning_rate=0.3, n_iters=5000, method="gd")
    gd_model.fit(X_train, y_train)
    gd_pred = gd_model.predict(X_test)

    sk_model = SklearnLinReg()
    sk_model.fit(X_train, y_train)
    sk_pred = sk_model.predict(X_test)

    plot_actual_vs_predicted(y_test, {
        "GD (from scratch)": gd_pred,
        "sklearn": sk_pred,
    })
    plot_residuals(y_test, gd_pred, label="GD (from scratch)")
    plot_3d_price_surface(X_train, y_train, feature_names)

    print("\nAll figures generated successfully.")
