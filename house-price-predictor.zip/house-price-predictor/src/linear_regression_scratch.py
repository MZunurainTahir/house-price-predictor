"""
linear_regression_scratch.py
------------------------------
Linear Regression implemented from scratch using NumPy only.

MATHEMATICAL INTUITION
=======================
Linear Regression models the target as a linear combination of features:

    y_hat = w·x + b

We want to find w, b that minimize the average squared error between
predictions and true values (Mean Squared Error):

    J(w, b) = (1/2m) * Σ (y_hat_i - y_i)^2

The 1/2 factor is a convention that makes the derivative cleaner (the 2
from the square cancels with it) - it doesn't change which w,b minimize J.

GRADIENTS
---------
    dJ/dw = (1/m) * X^T · (y_hat - y)
    dJ/db = (1/m) * Σ(y_hat - y)

Notice these are the SAME gradient formulas as logistic regression's
cross-entropy gradients - only y_hat differs (linear vs sigmoid). This
is not a coincidence: both are special cases of generalized linear
models, where the "canonical link function" makes the gradient take
this same clean form.

FOUR WAYS TO FIND w, b (ALL IMPLEMENTED HERE)
-----------------------------------------------
1. Normal Equation (closed-form): w = (X^T X)^-1 X^T y
   Exact solution in one step - no iteration needed. But computing a
   matrix inverse costs O(n^3) in the number of features, so it doesn't
   scale to very high-dimensional or huge datasets.

2. Batch Gradient Descent (GD): iterative, uses the full dataset's
   gradient every step. Converges smoothly toward the Normal Equation's
   exact answer.

3. Stochastic Gradient Descent (SGD): one random sample per step. Noisy
   but cheap per step.

4. Mini-batch Gradient Descent: small random batch per step. The
   practical middle ground used in real-world large-scale training.
"""

import numpy as np


class LinearRegressionScratch:
    def __init__(
        self,
        learning_rate: float = 0.01,
        n_iters: int = 1000,
        method: str = "gd",          # "gd", "sgd", "minibatch", or "normal_equation"
        batch_size: int = 16,
        random_state: int = 42,
    ):
        self.lr = learning_rate
        self.n_iters = n_iters
        self.method = method
        self.batch_size = batch_size
        self.random_state = random_state
        self.weights = None
        self.bias = None
        self.loss_history = []

    def _mse(self, y_true, y_pred) -> float:
        return np.mean((y_pred - y_true) ** 2)

    def fit(self, X: np.ndarray, y: np.ndarray):
        n_samples, n_features = X.shape

        if self.method == "normal_equation":
            # Closed-form solution: augment X with a bias column of 1s
            X_aug = np.hstack([np.ones((n_samples, 1)), X])
            # (X^T X)^-1 X^T y  -- using lstsq instead of explicit inverse
            # for numerical stability (equivalent solution, more robust)
            theta, _, _, _ = np.linalg.lstsq(X_aug, y, rcond=None)
            self.bias = theta[0]
            self.weights = theta[1:]
            y_pred = X @ self.weights + self.bias
            self.loss_history = [self._mse(y, y_pred)]
            return self

        rng = np.random.RandomState(self.random_state)
        self.weights = np.zeros(n_features)
        self.bias = 0.0
        self.loss_history = []

        for epoch in range(self.n_iters):
            if self.method == "gd":
                y_pred = X @ self.weights + self.bias
                grad_w = (1 / n_samples) * X.T @ (y_pred - y)
                grad_b = (1 / n_samples) * np.sum(y_pred - y)
                self.weights -= self.lr * grad_w
                self.bias -= self.lr * grad_b
                loss = self._mse(y, y_pred)

            elif self.method == "sgd":
                idx = rng.randint(0, n_samples)
                xi = X[idx : idx + 1]
                yi = y[idx : idx + 1]
                y_pred_i = xi @ self.weights + self.bias
                grad_w = xi.T @ (y_pred_i - yi)
                grad_b = np.sum(y_pred_i - yi)
                self.weights -= self.lr * grad_w.flatten()
                self.bias -= self.lr * grad_b
                full_pred = X @ self.weights + self.bias
                loss = self._mse(y, full_pred)

            elif self.method == "minibatch":
                idx = rng.choice(n_samples, size=min(self.batch_size, n_samples), replace=False)
                xb = X[idx]
                yb = y[idx]
                y_pred_b = xb @ self.weights + self.bias
                grad_w = (1 / len(idx)) * xb.T @ (y_pred_b - yb)
                grad_b = (1 / len(idx)) * np.sum(y_pred_b - yb)
                self.weights -= self.lr * grad_w
                self.bias -= self.lr * grad_b
                full_pred = X @ self.weights + self.bias
                loss = self._mse(y, full_pred)

            else:
                raise ValueError(f"Unknown method: {self.method}")

            self.loss_history.append(loss)

        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        return X @ self.weights + self.bias


if __name__ == "__main__":
    # smoke test on synthetic data with known ground truth
    rng = np.random.RandomState(0)
    X = rng.randn(300, 4)
    true_w = np.array([3.0, -1.5, 2.0, 0.5])
    true_b = 5.0
    y = X @ true_w + true_b + rng.randn(300) * 0.1  # small noise

    for method in ["normal_equation", "gd", "sgd", "minibatch"]:
        model = LinearRegressionScratch(learning_rate=0.1, n_iters=1000, method=method)
        model.fit(X, y)
        preds = model.predict(X)
        mse = np.mean((preds - y) ** 2)
        print(f"{method:16s} | MSE: {mse:.5f} | weights: {np.round(model.weights, 2)} | bias: {model.bias:.2f}")
