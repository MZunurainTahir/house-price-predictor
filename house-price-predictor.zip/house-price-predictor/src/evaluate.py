"""
evaluate.py
-----------
Regression evaluation metrics implemented from scratch (no sklearn.metrics),
used for a fair, apples-to-apples comparison with sklearn's LinearRegression.
"""

import numpy as np


def mse_scratch(y_true, y_pred) -> float:
    return np.mean((y_true - y_pred) ** 2)


def rmse_scratch(y_true, y_pred) -> float:
    return np.sqrt(mse_scratch(y_true, y_pred))


def mae_scratch(y_true, y_pred) -> float:
    return np.mean(np.abs(y_true - y_pred))


def r2_scratch(y_true, y_pred) -> float:
    """
    R^2 = 1 - (SS_residual / SS_total)
    SS_residual = sum of squared errors of the model
    SS_total    = sum of squared errors of always predicting the mean
    R^2 = 1 means perfect fit; R^2 = 0 means no better than predicting the mean.
    """
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    return 1 - (ss_res / ss_tot) if ss_tot > 0 else 0.0


def full_report(y_true, y_pred, label: str = "Model", log_target: bool = True) -> dict:
    report = {
        "label": label,
        "rmse_log": rmse_scratch(y_true, y_pred),
        "mae_log": mae_scratch(y_true, y_pred),
        "r2": r2_scratch(y_true, y_pred),
    }
    if log_target:
        # also report RMSE/MAE back in real dollars for interpretability
        y_true_dollars = np.expm1(y_true)
        y_pred_dollars = np.expm1(y_pred)
        report["rmse_dollars"] = rmse_scratch(y_true_dollars, y_pred_dollars)
        report["mae_dollars"] = mae_scratch(y_true_dollars, y_pred_dollars)
    return report


def print_report(report: dict):
    print(f"--- {report['label']} ---")
    print(f"  R^2 Score      : {report['r2']:.4f}")
    print(f"  RMSE (log)     : {report['rmse_log']:.4f}")
    print(f"  MAE  (log)     : {report['mae_log']:.4f}")
    if "rmse_dollars" in report:
        print(f"  RMSE ($)       : ${report['rmse_dollars']:,.0f}")
        print(f"  MAE  ($)       : ${report['mae_dollars']:,.0f}")
