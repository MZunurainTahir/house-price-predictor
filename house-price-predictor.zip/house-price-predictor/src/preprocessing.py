"""
preprocessing.py
-----------------
Loading, cleaning, feature selection, encoding, and scaling utilities
for the House Price Predictor project.
"""

import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "ames_housing.csv")

NUMERIC_FEATURES = [
    "OverallQual", "GrLivArea", "GarageCars", "GarageArea", "TotalBsmtSF",
    "1stFlrSF", "FullBath", "TotRmsAbvGrd", "YearBuilt", "YearRemodAdd", "Fireplaces",
]
CATEGORICAL_FEATURES = ["Neighborhood"]
TARGET_COL = "SalePrice"
RARE_NEIGHBORHOOD_THRESHOLD = 20  # neighborhoods with fewer houses get grouped into "Other"


def load_data(path: str = DATA_PATH) -> pd.DataFrame:
    df = pd.read_csv(path)
    cols = NUMERIC_FEATURES + CATEGORICAL_FEATURES + [TARGET_COL]
    return df[cols].copy()


def check_data_quality(df: pd.DataFrame) -> dict:
    return {
        "n_rows": len(df),
        "n_cols": df.shape[1],
        "missing_values": df.isnull().sum().sum(),
        "duplicate_rows": df.duplicated().sum(),
        "saleprice_min": df[TARGET_COL].min(),
        "saleprice_max": df[TARGET_COL].max(),
        "saleprice_mean": df[TARGET_COL].mean(),
        "saleprice_skew": df[TARGET_COL].skew(),
    }


def group_rare_neighborhoods(df: pd.DataFrame) -> pd.DataFrame:
    """Groups neighborhoods with fewer than RARE_NEIGHBORHOOD_THRESHOLD houses into 'Other'."""
    df = df.copy()
    counts = df["Neighborhood"].value_counts()
    rare = counts[counts < RARE_NEIGHBORHOOD_THRESHOLD].index
    df["Neighborhood"] = df["Neighborhood"].replace(rare, "Other")
    return df


class StandardScalerFromScratch:
    """Standardizes features to zero mean, unit variance. Fit on train only."""

    def __init__(self):
        self.mean_ = None
        self.std_ = None

    def fit(self, X: np.ndarray):
        self.mean_ = X.mean(axis=0)
        self.std_ = X.std(axis=0)
        self.std_[self.std_ == 0] = 1.0
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        return (X - self.mean_) / self.std_

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        self.fit(X)
        return self.transform(X)


def get_train_test_split(df: pd.DataFrame, test_size: float = 0.2, random_state: int = 42, log_target: bool = True):
    """
    - Groups rare neighborhoods into 'Other'
    - One-hot encodes Neighborhood
    - Log-transforms SalePrice (standard practice: price is right-skewed,
      log makes the relationship with features closer to linear and
      stabilizes variance for a linear model)
    - Splits 80/20
    - Scales numeric features with a from-scratch StandardScaler, fit on train only
    """
    df = group_rare_neighborhoods(df)
    df_encoded = pd.get_dummies(df, columns=CATEGORICAL_FEATURES, drop_first=True)

    y_col = TARGET_COL
    X = df_encoded.drop(columns=[y_col])
    y = df_encoded[y_col].values.astype(float)

    if log_target:
        y = np.log1p(y)  # log(1+y), inverse later with np.expm1

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    scaler = StandardScalerFromScratch()
    X_train_scaled = X_train.copy()
    X_test_scaled = X_test.copy()
    X_train_scaled[NUMERIC_FEATURES] = scaler.fit_transform(X_train[NUMERIC_FEATURES].values)
    X_test_scaled[NUMERIC_FEATURES] = scaler.transform(X_test[NUMERIC_FEATURES].values)

    return (
        X_train_scaled.values.astype(float),
        X_test_scaled.values.astype(float),
        y_train,
        y_test,
        X_train_scaled.columns.tolist(),
        scaler,
    )


if __name__ == "__main__":
    df = load_data()
    print("Data quality report:")
    for k, v in check_data_quality(df).items():
        print(f"  {k}: {v}")

    X_train, X_test, y_train, y_test, cols, scaler = get_train_test_split(df)
    print(f"\nTrain shape: {X_train.shape}, Test shape: {X_test.shape}")
    print(f"Feature columns ({len(cols)}): {cols}")
