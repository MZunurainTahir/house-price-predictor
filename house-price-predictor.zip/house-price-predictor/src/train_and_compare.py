"""
train_and_compare.py
---------------------
Main experiment script: trains the from-scratch Linear Regression
(Normal Equation, GD, SGD, Mini-batch) and sklearn's LinearRegression
on the same train/test split, then reports metrics for a fair comparison.
"""

import sys
import os
import time
import numpy as np
import pandas as pd

sys.path.append(os.path.dirname(__file__))

from preprocessing import load_data, get_train_test_split, check_data_quality
from linear_regression_scratch import LinearRegressionScratch
from evaluate import full_report, print_report

from sklearn.linear_model import LinearRegression as SklearnLinReg


def run():
    df = load_data()
    print("Data quality check:")
    for k, v in check_data_quality(df).items():
        print(f"  {k}: {v}")
    print()

    X_train, X_test, y_train, y_test, feature_names, scaler = get_train_test_split(df)

    results = []
    histories = {}

    configs = [
        ("Linear Regression (Normal Equation, from scratch)", "normal_equation", None, 1),
        ("Linear Regression (GD, from scratch)", "gd", 0.3, 5000),
        ("Linear Regression (SGD, from scratch)", "sgd", 0.01, 20000),
        ("Linear Regression (Mini-batch, from scratch)", "minibatch", 0.1, 8000),
    ]

    for label, method, lr, n_iters in configs:
        kwargs = {"method": method, "n_iters": n_iters}
        if lr is not None:
            kwargs["learning_rate"] = lr
        model = LinearRegressionScratch(**kwargs)

        t0 = time.time()
        model.fit(X_train, y_train)
        train_time = time.time() - t0

        y_pred = model.predict(X_test)
        report = full_report(y_test, y_pred, label=label)
        report["train_time_sec"] = train_time
        print_report(report)
        print(f"  Train time: {train_time:.4f}s\n")
        results.append(report)
        histories[label] = model.loss_history

    # sklearn baseline
    sk_model = SklearnLinReg()
    t0 = time.time()
    sk_model.fit(X_train, y_train)
    sk_train_time = time.time() - t0

    y_pred_sk = sk_model.predict(X_test)
    sk_report = full_report(y_test, y_pred_sk, label="Linear Regression (sklearn)")
    sk_report["train_time_sec"] = sk_train_time
    print_report(sk_report)
    print(f"  Train time: {sk_train_time:.4f}s\n")
    results.append(sk_report)

    results_df = pd.DataFrame(results)[
        ["label", "r2", "rmse_log", "mae_log", "rmse_dollars", "mae_dollars", "train_time_sec"]
    ]
    print("\n=== SUMMARY TABLE ===")
    print(results_df.to_string(index=False))

    results_df.to_csv(
        os.path.join(os.path.dirname(__file__), "..", "reports", "model_comparison_results.csv"),
        index=False,
    )

    return results_df, histories, X_train, X_test, y_train, y_test, feature_names, df


if __name__ == "__main__":
    run()
